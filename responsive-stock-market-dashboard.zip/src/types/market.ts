export type MarketState = 'OPEN' | 'CLOSED' | 'PRE-MARKET' | 'POST-MARKET';

export type TimeRange = '1D' | '1W' | '1M' | '1Y' | '5Y' | 'ALL';
export type ChartType = 'line' | 'candle';
export type CapCategory = 'All' | 'Large Cap' | 'Mid Cap' | 'Small Cap';

export interface ExchangeStatus {
  exchange: string;
  name: string;
  country: string;
  timezone: string;
  status: MarketState;
  localTime: string;
  nextEvent: string;
  countdownStr?: string;
}

export interface IndianIndexQuote {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  open: number;
  high: number;
  low: number;
  previousClose: number;
  volume?: number;
  exchange: 'NSE' | 'BSE';
  sparkline: number[];
  lastUpdated: string;
}

export interface StockFundamentals {
  marketCapCr: number;
  peRatio: number;
  pbRatio: number;
  industryPe: number;
  debtToEquity: number;
  roePercent: number;
  epsTtm: number;
  divYieldPercent: number;
  bookValue: number;
  faceValue: number;
}

export interface StockPerformance {
  todayLow: number;
  todayHigh: number;
  fiftyTwoWeekLow: number;
  fiftyTwoWeekHigh: number;
  openPrice: number;
  prevClose: number;
  volume: number;
  totalTradedValueCr: number;
  lowerCircuit: number;
  upperCircuit: number;
  atp: number; // Average Traded Price
}

export interface StockCompanyInfo {
  about: string;
  managingDirector: string;
  parentOrg: string;
  foundedYear: number;
  headquarters: string;
  nseSymbol: string;
  bseCode: string;
  isin: string;
  sector: string;
  industry: string;
  marketCapCategory: 'Large Cap' | 'Mid Cap' | 'Small Cap';
}

export interface IndianStockQuote {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  exchange: 'NSE' | 'BSE';
  currency: 'INR';
  sector: string;
  marketCapCategory: 'Large Cap' | 'Mid Cap' | 'Small Cap';
  sparkline: number[];
  performance: StockPerformance;
  fundamentals: StockFundamentals;
  companyInfo: StockCompanyInfo;
  lastUpdated: string;
  isFiftyTwoWeekHigh?: boolean;
  isFiftyTwoWeekLow?: boolean;
}

export interface SectorData {
  id: string;
  name: string;
  changePercent: number;
  advancing: number;
  declining: number;
  totalStocks: number;
  topStockName: string;
  topStockGain: number;
}

export interface CandleDataPoint {
  timestamp: number;
  timeStr: string;
  dateStr: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface HistoricalPoint {
  timestamp: number;
  timeStr: string;
  dateStr: string;
  price: number;
  open?: number;
  high?: number;
  low?: number;
  close?: number;
  volume?: number;
}

export interface ChartDataResult {
  points: HistoricalPoint[];
  candles: CandleDataPoint[];
  startPrice: number;
  currentPrice: number;
  change: number;
  changePercent: number;
  high: number;
  low: number;
  range: TimeRange;
}

export interface IndianMarketNewsItem {
  id: string;
  title: string;
  summary: string;
  source: string;
  url: string;
  publishedAt: string;
  tags: string[];
  sentiment?: 'positive' | 'negative' | 'neutral';
}

export interface MarketBreadth {
  advances: number;
  declines: number;
  unchanged: number;
  totalTraded: number;
  ratio: number;
}

export interface ApiConfig {
  provider: 'auto' | 'finnhub' | 'alphavantage';
  finnhubKey?: string;
  alphaVantageKey?: string;
  refreshInterval: number;
}

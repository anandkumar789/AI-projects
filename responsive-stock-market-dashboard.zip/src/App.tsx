import React, { useState, useEffect, useCallback } from 'react';
import {
  IndianStockQuote,
  IndianIndexQuote,
  SectorData,
  IndianMarketNewsItem,
  MarketBreadth,
  ExchangeStatus,
} from './types/market';
import {
  fetchIndianIndices,
  fetchIndianStocks,
  fetchIndianMovers,
  fetchIndianSectors,
  fetchIndianMarketNews,
  fetchStockDetail,
  calculateMarketBreadth,
} from './services/marketDataService';
import { getIndianMarketStatus } from './services/marketStatusService';
import { GrowwMobileShell } from './components/GrowwMobileShell';
import { GrowwHeader } from './components/GrowwHeader';
import { GrowwIndicesBar } from './components/GrowwIndicesBar';
import { GrowwExploreTab } from './components/GrowwExploreTab';
import { GrowwWatchlistTab } from './components/GrowwWatchlistTab';
import { GrowwSearchTab } from './components/GrowwSearchTab';
import { GrowwNewsTab } from './components/GrowwNewsTab';
import { GrowwStockDetailSheet } from './components/GrowwStockDetailSheet';

const LOCAL_STORAGE_WATCHLIST_KEY = 'groww_indian_stocks_watchlist_v1';

export const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'explore' | 'watchlist' | 'search' | 'news'>('explore');
  const [indices, setIndices] = useState<IndianIndexQuote[]>([]);
  const [stocks, setStocks] = useState<IndianStockQuote[]>([]);
  const [movers, setMovers] = useState<{
    gainers: IndianStockQuote[];
    losers: IndianStockQuote[];
    mostActive: IndianStockQuote[];
    fiftyTwoWeekHigh: IndianStockQuote[];
  }>({ gainers: [], losers: [], mostActive: [], fiftyTwoWeekHigh: [] });
  const [sectors, setSectors] = useState<SectorData[]>([]);
  const [news, setNews] = useState<IndianMarketNewsItem[]>([]);
  const [breadth, setBreadth] = useState<MarketBreadth>({
    advances: 1320,
    declines: 820,
    unchanged: 90,
    totalTraded: 2230,
    ratio: 1.61,
  });
  const [marketStatus, setMarketStatus] = useState<ExchangeStatus>(getIndianMarketStatus());
  const [isLoading, setIsLoading] = useState(false);

  // Watchlist state (Local browser storage)
  const [watchlistSymbols, setWatchlistSymbols] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_WATCHLIST_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return ['RELIANCE.NS', 'TCS.NS', 'HDFCBANK.NS', 'INFY.NS', 'TATAMOTORS.NS', 'ZOMATO.NS'];
  });

  // Selected Stock for Groww Sheet
  const [selectedStock, setSelectedStock] = useState<IndianStockQuote | null>(null);

  // Sync Watchlist to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_WATCHLIST_KEY, JSON.stringify(watchlistSymbols));
    } catch (err) {
      console.error('Failed to save watchlist:', err);
    }
  }, [watchlistSymbols]);

  // Update Exchange Status periodically
  useEffect(() => {
    const timer = setInterval(() => {
      setMarketStatus(getIndianMarketStatus());
    }, 10000);
    return () => clearInterval(timer);
  }, []);

  // Fetch all Indian Market Data
  const refreshMarketData = useCallback(async () => {
    setIsLoading(true);
    try {
      const [indicesRes, stocksRes, moversRes, sectorsRes, newsRes] = await Promise.allSettled([
        fetchIndianIndices(),
        fetchIndianStocks(),
        fetchIndianMovers(),
        fetchIndianSectors(),
        fetchIndianMarketNews(),
      ]);

      if (indicesRes.status === 'fulfilled') setIndices(indicesRes.value);
      if (stocksRes.status === 'fulfilled') {
        setStocks(stocksRes.value);
        setBreadth(calculateMarketBreadth(stocksRes.value));
      }
      if (moversRes.status === 'fulfilled') setMovers(moversRes.value);
      if (sectorsRes.status === 'fulfilled') setSectors(sectorsRes.value);
      if (newsRes.status === 'fulfilled') setNews(newsRes.value);
      setMarketStatus(getIndianMarketStatus());
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Initial Data Load
  useEffect(() => {
    refreshMarketData();
  }, [refreshMarketData]);

  // Toggle Watchlist
  const handleToggleWatchlist = (symbol: string) => {
    setWatchlistSymbols((prev) =>
      prev.includes(symbol) ? prev.filter((s) => s !== symbol) : [...prev, symbol]
    );
  };

  // Open Stock Detail
  const handleSelectStock = async (symbol: string) => {
    const stock = await fetchStockDetail(symbol);
    if (stock) {
      setSelectedStock(stock);
    }
  };

  // Filter watchlist quotes
  const watchlistQuotes = stocks.filter((s) => watchlistSymbols.includes(s.symbol));

  return (
    <GrowwMobileShell
      activeTab={activeTab}
      setActiveTab={setActiveTab}
      watchlistCount={watchlistSymbols.length}
      marketStatus={marketStatus}
    >
      {/* Groww Top Header */}
      <GrowwHeader
        status={marketStatus}
        isLoading={isLoading}
        onRefresh={refreshMarketData}
        onOpenSearch={() => setActiveTab('search')}
      />

      {/* Main Tab View */}
      <div className="pt-3">
        {/* 1. Explore Tab */}
        {activeTab === 'explore' && (
          <div className="space-y-4">
            {/* Indian Indices Carousel */}
            <GrowwIndicesBar
              indices={indices}
              onSelectIndex={handleSelectStock}
            />

            {/* Market Movers & Sectors Feed */}
            <GrowwExploreTab
              gainers={movers.gainers}
              losers={movers.losers}
              mostActive={movers.mostActive}
              fiftyTwoWeekHigh={movers.fiftyTwoWeekHigh}
              sectors={sectors}
              breadth={breadth}
              watchlistSymbols={watchlistSymbols}
              onSelectStock={handleSelectStock}
              onToggleWatchlist={handleToggleWatchlist}
            />
          </div>
        )}

        {/* 2. Watchlist Tab */}
        {activeTab === 'watchlist' && (
          <GrowwWatchlistTab
            watchlistQuotes={watchlistQuotes}
            watchlistSymbols={watchlistSymbols}
            onSelectStock={handleSelectStock}
            onRemoveFromWatchlist={handleToggleWatchlist}
            onOpenSearch={() => setActiveTab('search')}
          />
        )}

        {/* 3. Search Tab */}
        {activeTab === 'search' && (
          <GrowwSearchTab
            stocks={stocks}
            onSelectStock={handleSelectStock}
          />
        )}

        {/* 4. News Tab */}
        {activeTab === 'news' && (
          <GrowwNewsTab
            news={news}
            isLoading={isLoading}
          />
        )}
      </div>

      {/* Stock Detail Bottom Sheet / Modal */}
      {selectedStock && (
        <GrowwStockDetailSheet
          stock={selectedStock}
          onClose={() => setSelectedStock(null)}
          isWatchlisted={watchlistSymbols.includes(selectedStock.symbol)}
          onToggleWatchlist={handleToggleWatchlist}
        />
      )}
    </GrowwMobileShell>
  );
};

export default App;

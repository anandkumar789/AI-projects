import { ExchangeStatus, MarketState } from '../types/market';

/**
 * Calculates Indian Market Status (NSE / BSE) in Asia/Kolkata (IST)
 */
export function getIndianMarketStatus(): ExchangeStatus {
  const tz = 'Asia/Kolkata';
  const now = new Date();

  const formatter = new Intl.DateTimeFormat('en-US', {
    timeZone: tz,
    weekday: 'short',
    hour: 'numeric',
    minute: 'numeric',
    second: 'numeric',
    hour12: false,
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });

  const parts = formatter.formatToParts(now);
  const partMap: Record<string, string> = {};
  parts.forEach((p) => {
    partMap[p.type] = p.value;
  });

  const weekdayStr = partMap.weekday || '';
  const dayMap: Record<string, number> = {
    Sun: 0,
    Mon: 1,
    Tue: 2,
    Wed: 3,
    Thu: 4,
    Fri: 5,
    Sat: 6,
  };
  const dayOfWeek = dayMap[weekdayStr] ?? now.getDay();
  const hours = parseInt(partMap.hour, 10) || 0;
  const minutes = parseInt(partMap.minute, 10) || 0;

  const displayFormatter = new Intl.DateTimeFormat('en-US', {
    timeZone: tz,
    hour: 'numeric',
    minute: 'numeric',
    second: 'numeric',
    hour12: true,
  });

  const totalMinutes = hours * 60 + minutes;
  const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;

  let status: MarketState = 'CLOSED';
  let nextEvent = 'Opens Mon 9:15 AM IST';

  if (!isWeekend) {
    // 9:00 AM (540 min) to 9:15 AM (555 min) => PRE-MARKET
    if (totalMinutes >= 540 && totalMinutes < 555) {
      status = 'PRE-MARKET';
      nextEvent = 'Regular market opens at 9:15 AM IST';
    }
    // 9:15 AM (555 min) to 15:30 PM (930 min) => OPEN
    else if (totalMinutes >= 555 && totalMinutes < 930) {
      status = 'OPEN';
      nextEvent = 'Closes at 3:30 PM IST';
    }
    // 15:30 PM (930 min) to 16:00 PM (960 min) => POST-MARKET
    else if (totalMinutes >= 930 && totalMinutes < 960) {
      status = 'POST-MARKET';
      nextEvent = 'Post-market closes at 4:00 PM IST';
    }
    // Before 9:00 AM
    else if (totalMinutes < 540) {
      status = 'CLOSED';
      nextEvent = 'Pre-market opens at 9:00 AM IST';
    }
    // After 16:00 PM
    else {
      status = 'CLOSED';
      nextEvent = dayOfWeek === 5 ? 'Opens Mon 9:15 AM IST' : 'Opens tomorrow 9:15 AM IST';
    }
  } else {
    status = 'CLOSED';
    nextEvent = 'Opens Monday 9:15 AM IST';
  }

  return {
    exchange: 'NSE/BSE',
    name: 'National Stock Exchange of India',
    country: 'India',
    timezone: 'Asia/Kolkata (IST)',
    status,
    localTime: displayFormatter.format(now),
    nextEvent,
  };
}

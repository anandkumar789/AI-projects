import React, { useState } from 'react';
import { IndianStockQuote } from '../types/market';
import { formatIndianCurrency } from '../services/marketDataService';
import {
  Bookmark,
  TrendingUp,
  TrendingDown,
  Trash2,
  Plus,
  ArrowUpDown,
  Search,
} from 'lucide-react';

interface GrowwWatchlistTabProps {
  watchlistQuotes: IndianStockQuote[];
  watchlistSymbols: string[];
  onSelectStock: (symbol: string) => void;
  onRemoveFromWatchlist: (symbol: string) => void;
  onOpenSearch: () => void;
}

export const GrowwWatchlistTab: React.FC<GrowwWatchlistTabProps> = ({
  watchlistQuotes,
  watchlistSymbols,
  onSelectStock,
  onRemoveFromWatchlist,
  onOpenSearch,
}) => {
  const [activeList, setActiveList] = useState<'All' | 'High Growth' | 'Banking' | 'IT'>('All');
  const [sortBy, setSortBy] = useState<'gain' | 'price' | 'name'>('gain');
  const [searchQuery, setSearchQuery] = useState('');

  // Filter & Sort
  let filtered = watchlistQuotes.filter((q) => {
    if (activeList === 'Banking') return q.sector.toLowerCase().includes('bank');
    if (activeList === 'IT') return q.sector.toLowerCase().includes('information') || q.sector.toLowerCase().includes('it');
    return true;
  });

  if (searchQuery.trim()) {
    const q = searchQuery.toLowerCase();
    filtered = filtered.filter(
      (s) =>
        s.name.toLowerCase().includes(q) ||
        s.companyInfo.nseSymbol.toLowerCase().includes(q)
    );
  }

  const sortedList = [...filtered].sort((a, b) => {
    if (sortBy === 'gain') return b.changePercent - a.changePercent;
    if (sortBy === 'price') return b.price - a.price;
    return a.name.localeCompare(b.name);
  });

  return (
    <div className="space-y-4 pb-6">
      {/* Watchlist Category Tabs */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1 bg-[#181818] p-1 rounded-xl border border-[#262626] text-xs">
          {(['All', 'Banking', 'IT'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveList(tab)}
              className={`px-3 py-1 rounded-lg font-bold transition-all ${
                activeList === tab
                  ? 'bg-[#00D09C] text-black shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        <button
          onClick={onOpenSearch}
          className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-[#00D09C]/15 text-[#00D09C] border border-[#00D09C]/30 text-xs font-bold hover:bg-[#00D09C]/25 transition-all"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Stock</span>
        </button>
      </div>

      {/* Filter and Sort bar */}
      <div className="flex items-center gap-2">
        <div className="flex-1 relative">
          <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search in watchlist..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#181818] border border-[#262626] rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-zinc-500 outline-none"
          />
        </div>

        {/* Sort Switcher */}
        <button
          onClick={() => {
            setSortBy(sortBy === 'gain' ? 'price' : sortBy === 'price' ? 'name' : 'gain');
          }}
          className="flex items-center gap-1 bg-[#181818] border border-[#262626] px-2.5 py-1.5 rounded-xl text-xs text-zinc-400 font-mono"
        >
          <ArrowUpDown className="w-3 h-3 text-[#00D09C]" />
          <span>{sortBy === 'gain' ? '% Change' : sortBy === 'price' ? 'Price' : 'A-Z'}</span>
        </button>
      </div>

      {/* Watchlist Body */}
      {watchlistSymbols.length === 0 ? (
        <div className="text-center py-12 px-4 bg-[#181818] rounded-2xl border border-dashed border-zinc-800 space-y-3">
          <Bookmark className="w-10 h-10 text-zinc-600 mx-auto" />
          <h3 className="font-bold text-white text-base">Your Watchlist is empty</h3>
          <p className="text-xs text-zinc-400 max-w-xs mx-auto">
            Track your favorite Indian equities like Reliance, TCS, HDFC Bank, Infosys and Tata Motors in one place.
          </p>
          <button
            onClick={onOpenSearch}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#00D09C] text-black text-xs font-bold shadow-md shadow-[#00D09C]/20"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Search & Add Stocks</span>
          </button>
        </div>
      ) : (
        <div className="bg-[#181818] rounded-2xl border border-[#262626] p-3 divide-y divide-[#242424]">
          {sortedList.map((stock) => {
            const isPositive = stock.changePercent >= 0;

            return (
              <div
                key={stock.symbol}
                onClick={() => onSelectStock(stock.symbol)}
                className="group py-3 flex items-center justify-between hover:bg-[#202020] -mx-1 px-2 rounded-xl cursor-pointer transition-colors"
              >
                {/* Left: Monogram and title */}
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-zinc-800 to-zinc-900 border border-zinc-700/80 flex items-center justify-center text-xs font-bold text-[#00D09C]">
                    {stock.companyInfo.nseSymbol.slice(0, 2)}
                  </div>
                  <div>
                    <div className="text-sm font-bold text-white group-hover:text-[#00D09C] transition-colors leading-snug">
                      {stock.name}
                    </div>
                    <div className="text-[11px] text-zinc-500 font-mono">
                      {stock.companyInfo.nseSymbol} • {stock.companyInfo.industry}
                    </div>
                  </div>
                </div>

                {/* Right: Price & Delete */}
                <div className="flex items-center gap-3 text-right">
                  <div>
                    <div className="text-sm font-bold font-mono text-white">
                      {formatIndianCurrency(stock.price)}
                    </div>
                    <div
                      className={`text-[11px] font-mono font-semibold flex items-center justify-end gap-0.5 ${
                        isPositive ? 'text-[#00D09C]' : 'text-[#EF4444]'
                      }`}
                    >
                      {isPositive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                      <span>
                        {isPositive ? '+' : ''}
                        {stock.changePercent.toFixed(2)}%
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onRemoveFromWatchlist(stock.symbol);
                    }}
                    title="Remove from watchlist"
                    className="p-1.5 rounded-lg text-zinc-500 hover:text-red-400 hover:bg-red-500/10 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

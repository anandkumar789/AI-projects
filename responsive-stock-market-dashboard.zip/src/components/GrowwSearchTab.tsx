import React, { useState, useEffect, useRef } from 'react';
import { IndianStockQuote } from '../types/market';
import { formatIndianCurrency } from '../services/marketDataService';
import {
  Search,
  X,
  TrendingUp,
  TrendingDown,
} from 'lucide-react';

interface GrowwSearchTabProps {
  stocks: IndianStockQuote[];
  onSelectStock: (symbol: string) => void;
}

export const GrowwSearchTab: React.FC<GrowwSearchTabProps> = ({
  stocks,
  onSelectStock,
}) => {
  const [query, setQuery] = useState('');
  const [filterTag, setFilterTag] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const tags = [
    'NIFTY 50',
    'Banking',
    'IT Giants',
    'Auto & EV',
    'Energy',
    'Pharma',
    'High Growth',
  ];

  let results = [...stocks];

  if (filterTag) {
    if (filterTag === 'Banking') results = results.filter((s) => s.sector.includes('Banking'));
    if (filterTag === 'IT Giants') results = results.filter((s) => s.sector.includes('IT'));
    if (filterTag === 'Auto & EV') results = results.filter((s) => s.sector.includes('Auto'));
    if (filterTag === 'Energy') results = results.filter((s) => s.sector.includes('Energy') || s.sector.includes('Oil'));
    if (filterTag === 'Pharma') results = results.filter((s) => s.sector.includes('Pharma'));
    if (filterTag === 'High Growth') results = results.filter((s) => s.changePercent > 1.5);
  }

  if (query.trim()) {
    const q = query.toLowerCase().trim();
    results = results.filter(
      (s) =>
        s.name.toLowerCase().includes(q) ||
        s.symbol.toLowerCase().includes(q) ||
        s.companyInfo.nseSymbol.toLowerCase().includes(q) ||
        s.companyInfo.industry.toLowerCase().includes(q)
    );
  }

  return (
    <div className="space-y-4 pb-6">
      {/* Mobile Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-[#00D09C] absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search Indian stocks (e.g. Reliance, TCS, INFY)..."
          className="w-full bg-[#181818] border border-[#2c2c2c] focus:border-[#00D09C] rounded-2xl pl-10 pr-9 py-3 text-sm text-white placeholder-zinc-500 outline-none transition-colors"
        />
        {query && (
          <button
            onClick={() => setQuery('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-zinc-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Suggested Quick Filter Tags */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none -mx-4 px-4 sm:mx-0 sm:px-0">
        <button
          onClick={() => setFilterTag(null)}
          className={`shrink-0 px-3 py-1 rounded-full text-xs font-bold transition-all ${
            filterTag === null
              ? 'bg-[#00D09C] text-black shadow-sm'
              : 'bg-[#181818] text-zinc-400 border border-[#282828]'
          }`}
        >
          All Equities
        </button>

        {tags.map((tag) => (
          <button
            key={tag}
            onClick={() => setFilterTag(tag === filterTag ? null : tag)}
            className={`shrink-0 px-3 py-1 rounded-full text-xs font-bold transition-all ${
              filterTag === tag
                ? 'bg-[#00D09C] text-black shadow-sm'
                : 'bg-[#181818] text-zinc-400 border border-[#282828]'
            }`}
          >
            {tag}
          </button>
        ))}
      </div>

      {/* Search Results */}
      <div className="bg-[#181818] rounded-2xl border border-[#262626] p-3 divide-y divide-[#242424]">
        <div className="px-2 py-1 text-[11px] font-semibold text-zinc-500 uppercase tracking-wider flex justify-between">
          <span>{query ? `Search results for "${query}"` : 'Popular Indian Stocks'}</span>
          <span>{results.length} Stocks</span>
        </div>

        {results.length === 0 ? (
          <div className="py-8 text-center text-zinc-500 text-xs">
            No Indian stocks matching "{query}". Try searching by NSE ticker like RELIANCE, TCS, or HDFCBANK.
          </div>
        ) : (
          results.map((stock) => {
            const isPos = stock.changePercent >= 0;

            return (
              <div
                key={stock.symbol}
                onClick={() => onSelectStock(stock.symbol)}
                className="group py-3 flex items-center justify-between hover:bg-[#202020] -mx-1 px-2 rounded-xl cursor-pointer transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-zinc-800 to-zinc-900 border border-zinc-700/80 flex items-center justify-center text-xs font-bold text-[#00D09C]">
                    {stock.companyInfo.nseSymbol.slice(0, 2)}
                  </div>
                  <div>
                    <div className="text-sm font-bold text-white group-hover:text-[#00D09C] transition-colors leading-snug">
                      {stock.name}
                    </div>
                    <div className="text-[11px] text-zinc-500 font-mono">
                      {stock.companyInfo.nseSymbol} • {stock.companyInfo.industry} • {stock.marketCapCategory}
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-sm font-bold font-mono text-white">
                    {formatIndianCurrency(stock.price)}
                  </div>
                  <div
                    className={`text-[11px] font-mono font-semibold flex items-center justify-end gap-0.5 ${
                      isPos ? 'text-[#00D09C]' : 'text-[#EF4444]'
                    }`}
                  >
                    {isPos ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                    <span>
                      {isPos ? '+' : ''}
                      {stock.changePercent.toFixed(2)}%
                    </span>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

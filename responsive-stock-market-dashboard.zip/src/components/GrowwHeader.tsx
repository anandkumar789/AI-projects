import React from 'react';
import { Search, RefreshCw, Clock, TrendingUp } from 'lucide-react';
import { ExchangeStatus } from '../types/market';

interface GrowwHeaderProps {
  status: ExchangeStatus;
  isLoading: boolean;
  onRefresh: () => void;
  onOpenSearch: () => void;
}

export const GrowwHeader: React.FC<GrowwHeaderProps> = ({
  status,
  isLoading,
  onRefresh,
  onOpenSearch,
}) => {
  const isMarketOpen = status.status === 'OPEN';

  return (
    <div className="sticky top-0 z-30 bg-[#121212]/95 backdrop-blur-md px-4 pt-2 pb-3 border-b border-[#222222] space-y-2.5">
      {/* Top row: Brand & Status Pill */}
      <div className="flex items-center justify-between">
        {/* Groww Brand Logo & Name */}
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#00b386] to-[#00D09C] flex items-center justify-center shadow-md shadow-[#00D09C]/20">
            <TrendingUp className="w-5 h-5 text-black stroke-[2.5]" />
          </div>
          <div>
            <h1 className="text-base font-extrabold text-white tracking-tight flex items-center gap-1.5 leading-tight">
              Groww
              <span className="text-[10px] uppercase font-bold text-[#00D09C] bg-[#00D09C]/10 px-1.5 py-0.2 rounded border border-[#00D09C]/20 font-mono">
                Stocks
              </span>
            </h1>
          </div>
        </div>

        {/* Right side: Market Status & Refresh Button */}
        <div className="flex items-center gap-2 text-xs">
          {/* Status Badge */}
          <div
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[11px] font-semibold ${
              isMarketOpen
                ? 'bg-[#00D09C]/10 text-[#00D09C] border-[#00D09C]/30'
                : 'bg-zinc-800 text-zinc-400 border-zinc-700'
            }`}
          >
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                isMarketOpen ? 'bg-[#00D09C] animate-pulse' : 'bg-zinc-500'
              }`}
            />
            <span>NSE: {status.status}</span>
          </div>

          {/* Refresh Action */}
          <button
            onClick={onRefresh}
            disabled={isLoading}
            className="p-1.5 rounded-full bg-[#1e1e1e] hover:bg-[#282828] text-zinc-300 border border-[#2e2e2e] transition-colors disabled:opacity-50"
            title="Refresh Quotes"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-[#00D09C]' : ''}`} />
          </button>
        </div>
      </div>

      {/* Groww Search Bar Input Pill */}
      <div
        onClick={onOpenSearch}
        className="w-full bg-[#181818] hover:bg-[#202020] border border-[#2c2c2c] rounded-2xl px-3.5 py-2.5 flex items-center justify-between cursor-pointer transition-all shadow-inner"
      >
        <div className="flex items-center gap-2.5 text-zinc-400 text-xs sm:text-sm">
          <Search className="w-4 h-4 text-[#00D09C]" />
          <span>Search Indian stocks, indices, F&O...</span>
        </div>

        <div className="flex items-center gap-1 text-[10px] text-zinc-500 font-mono bg-[#222222] px-2 py-0.5 rounded-md border border-[#333333]">
          <Clock className="w-2.5 h-2.5" />
          <span>IST</span>
        </div>
      </div>
    </div>
  );
};

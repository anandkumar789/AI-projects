import React, { useState } from 'react';
import { IndianMarketNewsItem } from '../types/market';
import { Newspaper, ExternalLink, Clock } from 'lucide-react';

interface GrowwNewsTabProps {
  news: IndianMarketNewsItem[];
  isLoading: boolean;
}

export const GrowwNewsTab: React.FC<GrowwNewsTabProps> = ({ news, isLoading }) => {
  const [selectedTag, setSelectedTag] = useState<string | null>(null);

  const allTags = ['All', 'NIFTY 50', 'Banking', 'Auto', 'Defence', 'Retail'];

  const filtered = selectedTag && selectedTag !== 'All'
    ? news.filter((item) => item.tags.some((t) => t.toLowerCase().includes(selectedTag.toLowerCase())))
    : news;

  const getRelativeTime = (isoString: string) => {
    try {
      const now = Date.now();
      const pub = new Date(isoString).getTime();
      const diffMin = Math.floor((now - pub) / 60000);
      if (diffMin < 1) return 'Just now';
      if (diffMin < 60) return `${diffMin}m ago`;
      const diffHours = Math.floor(diffMin / 60);
      if (diffHours < 24) return `${diffHours}h ago`;
      return `${Math.floor(diffHours / 24)}d ago`;
    } catch {
      return 'Recent';
    }
  };

  return (
    <div className="space-y-4 pb-6">
      {/* Header and Tag Selector */}
      <div className="flex items-center justify-between">
        <span className="text-xs font-bold uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
          <Newspaper className="w-3.5 h-3.5 text-[#00D09C]" /> Groww Market Digest
        </span>
        <span className="text-[11px] text-[#00D09C] font-mono">India Live</span>
      </div>

      {/* Tags Carousel */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none -mx-4 px-4 sm:mx-0 sm:px-0">
        {allTags.map((tag) => (
          <button
            key={tag}
            onClick={() => setSelectedTag(tag === 'All' ? null : tag)}
            className={`shrink-0 px-3 py-1 rounded-full text-xs font-bold transition-all ${
              (selectedTag === null && tag === 'All') || selectedTag === tag
                ? 'bg-[#00D09C] text-black shadow-sm'
                : 'bg-[#181818] text-zinc-400 border border-[#282828]'
            }`}
          >
            {tag}
          </button>
        ))}
      </div>

      {/* News Feed */}
      {isLoading && news.length === 0 ? (
        <div className="space-y-3">
          {[1, 2, 3, 4].map((n) => (
            <div key={n} className="h-24 bg-[#181818] rounded-2xl animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((item) => (
            <a
              key={item.id}
              href={item.url}
              target="_blank"
              rel="noopener noreferrer"
              className="block bg-[#181818] hover:bg-[#202020] border border-[#262626] rounded-2xl p-4 transition-all group"
            >
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-[10px] font-bold text-[#00D09C] bg-[#00D09C]/10 px-2 py-0.5 rounded-full border border-[#00D09C]/20 uppercase tracking-wider">
                  {item.source}
                </span>

                <span className="text-[10px] text-zinc-500 font-mono flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {getRelativeTime(item.publishedAt)}
                </span>
              </div>

              <h3 className="font-bold text-white text-sm group-hover:text-[#00D09C] transition-colors leading-snug">
                {item.title}
              </h3>

              <p className="text-xs text-zinc-400 mt-1.5 line-clamp-2 leading-relaxed">
                {item.summary}
              </p>

              <div className="flex items-center justify-between text-[11px] text-zinc-500 group-hover:text-[#00D09C] pt-2.5 border-t border-[#242424] mt-2.5 font-medium transition-colors">
                <div className="flex items-center gap-1.5">
                  {item.tags.map((t) => (
                    <span key={t} className="text-[10px] text-zinc-400 font-mono">
                      #{t}
                    </span>
                  ))}
                </div>

                <span className="flex items-center">
                  Read full story <ExternalLink className="w-3 h-3 ml-1" />
                </span>
              </div>
            </a>
          ))}
        </div>
      )}
    </div>
  );
};

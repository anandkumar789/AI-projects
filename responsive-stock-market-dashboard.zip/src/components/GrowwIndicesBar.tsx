import React from 'react';
import { IndianIndexQuote } from '../types/market';
import { formatIndianNumber } from '../services/marketDataService';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface GrowwIndicesBarProps {
  indices: IndianIndexQuote[];
  onSelectIndex: (symbol: string) => void;
}

export const GrowwIndicesBar: React.FC<GrowwIndicesBarProps> = ({
  indices,
  onSelectIndex,
}) => {
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between px-1">
        <span className="text-xs font-bold uppercase tracking-wider text-zinc-400">
          Indian Market Indices
        </span>
        <span className="text-[11px] text-[#00D09C] font-mono font-medium">
          NSE & BSE Live
        </span>
      </div>

      {/* Horizontal Scrollable Carousel */}
      <div className="flex items-center gap-2.5 overflow-x-auto pb-1 scrollbar-none -mx-4 px-4 sm:mx-0 sm:px-0">
        {indices.map((idx) => {
          const isPositive = idx.changePercent >= 0;
          const sparkline = idx.sparkline || [];
          const minSpark = Math.min(...sparkline);
          const maxSpark = Math.max(...sparkline);
          const sparkRange = maxSpark - minSpark || 1;

          // Build mini SVG sparkline
          const sparkPoints = sparkline
            .map((val, i) => {
              const x = (i / Math.max(1, sparkline.length - 1)) * 54;
              const y = 20 - ((val - minSpark) / sparkRange) * 16;
              return `${x},${y}`;
            })
            .join(' ');

          return (
            <div
              key={idx.symbol}
              onClick={() => onSelectIndex(idx.symbol)}
              className="shrink-0 w-44 bg-[#181818] hover:bg-[#202020] active:scale-[0.98] border border-[#282828] rounded-2xl p-3 cursor-pointer transition-all flex flex-col justify-between select-none shadow-sm"
            >
              <div className="flex items-start justify-between gap-1 mb-1.5">
                <div>
                  <h3 className="font-bold text-white text-xs truncate max-w-[100px]">
                    {idx.name}
                  </h3>
                  <span className="text-[10px] text-zinc-500 font-mono">
                    {idx.exchange}
                  </span>
                </div>

                {/* Mini Sparkline SVG */}
                <svg viewBox="0 0 54 22" className="w-14 h-6 overflow-visible">
                  <polyline
                    fill="none"
                    stroke={isPositive ? '#00D09C' : '#EF4444'}
                    strokeWidth="1.8"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    points={sparkPoints}
                  />
                </svg>
              </div>

              <div>
                <div className="text-sm font-bold font-mono text-white tracking-tight">
                  {formatIndianNumber(idx.price)}
                </div>
                <div
                  className={`flex items-center gap-0.5 text-[11px] font-mono font-semibold ${
                    isPositive ? 'text-[#00D09C]' : 'text-[#EF4444]'
                  }`}
                >
                  {isPositive ? (
                    <TrendingUp className="w-3 h-3" />
                  ) : (
                    <TrendingDown className="w-3 h-3" />
                  )}
                  <span>
                    {isPositive ? '+' : ''}
                    {formatIndianNumber(idx.change)} ({isPositive ? '+' : ''}
                    {idx.changePercent.toFixed(2)}%)
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

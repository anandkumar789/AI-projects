import React, { useState, useEffect } from 'react';
import {
  Compass,
  Bookmark,
  Search,
  Newspaper,
  Wifi,
  Battery,
  Smartphone,
  Maximize2,
  Minimize2,
} from 'lucide-react';
import { ExchangeStatus } from '../types/market';

interface GrowwMobileShellProps {
  children: React.ReactNode;
  activeTab: 'explore' | 'watchlist' | 'search' | 'news';
  setActiveTab: (tab: 'explore' | 'watchlist' | 'search' | 'news') => void;
  watchlistCount: number;
  marketStatus?: ExchangeStatus;
}

export const GrowwMobileShell: React.FC<GrowwMobileShellProps> = ({
  children,
  activeTab,
  setActiveTab,
  watchlistCount,
}) => {
  const [isFramed, setIsFramed] = useState(false);
  const [currentTimeStr, setCurrentTimeStr] = useState('');

  // Update clock in status bar
  useEffect(() => {
    const updateTime = () => {
      const d = new Date();
      setCurrentTimeStr(
        d.toLocaleTimeString('en-IN', {
          hour: '2-digit',
          minute: '2-digit',
          hour12: true,
        })
      );
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white flex flex-col items-center justify-start antialiased selection:bg-[#00D09C] selection:text-black">
      {/* Top Desktop Helper Toolbar (Hidden on true mobile) */}
      <aside aria-label="Device view switcher" className="hidden lg:flex items-center justify-between w-full max-w-lg px-4 py-2 text-xs text-zinc-400">
        <div className="flex items-center gap-2">
          <Smartphone className="w-3.5 h-3.5 text-[#00D09C]" />
          <span>Groww Mobile View (Android & iOS)</span>
        </div>

        <button
          onClick={() => setIsFramed(!isFramed)}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#181818] hover:bg-[#222222] border border-[#2a2a2a] text-zinc-300 transition-colors"
        >
          {isFramed ? <Minimize2 className="w-3 h-3" /> : <Maximize2 className="w-3 h-3" />}
          <span>{isFramed ? 'Full View' : 'Phone Frame Mode'}</span>
        </button>
      </aside>

      {/* Main Mobile App Container */}
      <div
        className={`w-full bg-[#121212] flex flex-col transition-all duration-200 ${
          isFramed
            ? 'max-w-md my-4 rounded-[40px] border-[8px] border-[#222222] shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] min-h-[850px] max-h-[92vh] overflow-hidden'
            : 'max-w-lg sm:border-x sm:border-[#222222] min-h-screen'
        }`}
      >
        {/* Mobile OS Status Bar (iOS / Android Style) */}
        <div className="sticky top-0 z-40 bg-[#121212] px-5 pt-2 pb-1 flex items-center justify-between text-xs text-zinc-300 select-none">
          {/* Time (Asia/Kolkata IST) */}
          <span className="font-semibold text-[13px] tracking-tight text-white font-mono">
            {currentTimeStr || '10:42 AM'}
          </span>

          {/* Dynamic Island / Camera Notch representation for framed mode */}
          {isFramed && (
            <div className="w-24 h-4 bg-black rounded-full border border-zinc-800/80 -mt-0.5" />
          )}

          {/* Network Icons & Battery */}
          <div className="flex items-center gap-1.5 text-zinc-300">
            <span className="text-[10px] font-bold font-mono tracking-tight text-[#00D09C]">5G</span>
            <Wifi className="w-3.5 h-3.5" />
            <div className="flex items-center gap-1">
              <span className="text-[10px] font-mono text-zinc-400">98%</span>
              <Battery className="w-4 h-4 text-[#00D09C] fill-[#00D09C]" />
            </div>
          </div>
        </div>

        {/* Content Viewport */}
        <div className="flex-1 overflow-y-auto px-4 pt-2 pb-20">
          {children}
        </div>

        {/* Groww Signature Mobile Bottom Navigation Bar */}
        <div className="sticky bottom-0 z-40 bg-[#121212]/95 backdrop-blur-lg border-t border-[#222222] px-2 py-1.5 flex items-center justify-around select-none">
          {/* 1. Explore Tab */}
          <button
            onClick={() => setActiveTab('explore')}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition-all ${
              activeTab === 'explore'
                ? 'text-[#00D09C] font-bold'
                : 'text-zinc-500 hover:text-zinc-300 font-medium'
            }`}
          >
            <Compass
              className={`w-5 h-5 transition-transform ${
                activeTab === 'explore' ? 'scale-110 stroke-[2.5]' : ''
              }`}
            />
            <span className="text-[10px] tracking-tight">Explore</span>
          </button>

          {/* 2. Watchlist Tab */}
          <button
            onClick={() => setActiveTab('watchlist')}
            className={`relative flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition-all ${
              activeTab === 'watchlist'
                ? 'text-[#00D09C] font-bold'
                : 'text-zinc-500 hover:text-zinc-300 font-medium'
            }`}
          >
            <div className="relative">
              <Bookmark
                className={`w-5 h-5 transition-transform ${
                  activeTab === 'watchlist' ? 'scale-110 stroke-[2.5] fill-[#00D09C]' : ''
                }`}
              />
              {watchlistCount > 0 && (
                <span className="absolute -top-1 -right-2 bg-[#00D09C] text-black text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center">
                  {watchlistCount}
                </span>
              )}
            </div>
            <span className="text-[10px] tracking-tight">Watchlist</span>
          </button>

          {/* 3. Search Tab */}
          <button
            onClick={() => setActiveTab('search')}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition-all ${
              activeTab === 'search'
                ? 'text-[#00D09C] font-bold'
                : 'text-zinc-500 hover:text-zinc-300 font-medium'
            }`}
          >
            <Search
              className={`w-5 h-5 transition-transform ${
                activeTab === 'search' ? 'scale-110 stroke-[2.5]' : ''
              }`}
            />
            <span className="text-[10px] tracking-tight">Search</span>
          </button>

          {/* 4. News Tab */}
          <button
            onClick={() => setActiveTab('news')}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition-all ${
              activeTab === 'news'
                ? 'text-[#00D09C] font-bold'
                : 'text-zinc-500 hover:text-zinc-300 font-medium'
            }`}
          >
            <Newspaper
              className={`w-5 h-5 transition-transform ${
                activeTab === 'news' ? 'scale-110 stroke-[2.5]' : ''
              }`}
            />
            <span className="text-[10px] tracking-tight">News</span>
          </button>
        </div>

        {/* iPhone Bottom Home Swipe Indicator */}
        <div className="bg-[#121212] py-1 flex justify-center">
          <div className="w-32 h-1 bg-zinc-700 rounded-full" />
        </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect, useRef } from 'react';
import {
  IndianStockQuote,
  TimeRange,
  ChartType,
  ChartDataResult,
  HistoricalPoint,
} from '../types/market';
import { fetchStockChartData, formatIndianCurrency, formatIndianNumber, formatIndianCompact } from '../services/marketDataService';
import {
  X,
  Bookmark,
  TrendingUp,
  TrendingDown,
  Clock,
  Building2,
  Share2,
  CandlestickChart as CandleIcon,
  LineChart as LineIcon,
} from 'lucide-react';

interface GrowwStockDetailSheetProps {
  stock: IndianStockQuote | null;
  onClose: () => void;
  isWatchlisted: boolean;
  onToggleWatchlist: (symbol: string) => void;
}

export const GrowwStockDetailSheet: React.FC<GrowwStockDetailSheetProps> = ({
  stock,
  onClose,
  isWatchlisted,
  onToggleWatchlist,
}) => {
  const [exchange, setExchange] = useState<'NSE' | 'BSE'>('NSE');
  const [timeRange, setTimeRange] = useState<TimeRange>('1D');
  const [chartType, setChartType] = useState<ChartType>('line');
  const [chartData, setChartData] = useState<ChartDataResult | null>(null);
  const [hoveredPoint, setHoveredPoint] = useState<HistoricalPoint | null>(null);
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  const [showShareToast, setShowShareToast] = useState(false);
  const chartSvgRef = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    if (!stock) return;
    const data = fetchStockChartData(
      stock.symbol,
      stock.price,
      stock.changePercent,
      timeRange,
      stock.performance.todayLow,
      stock.performance.todayHigh,
      stock.performance.prevClose
    );
    data.then((res) => {
      setChartData(res);
      setHoveredPoint(null);
      setHoveredIndex(null);
    });
  }, [stock, timeRange]);

  if (!stock) return null;

  const currentPrice = hoveredPoint ? hoveredPoint.price : stock.price;
  const initialPrice = chartData ? chartData.startPrice : stock.performance.prevClose;
  const activeChange = Number((currentPrice - initialPrice).toFixed(2));
  const activeChangePct = Number(((activeChange / (initialPrice || 1)) * 100).toFixed(2));
  const isPositive = activeChangePct >= 0;

  // Chart Dimensions
  const svgWidth = 360;
  const svgHeight = 200;
  const paddingX = 12;
  const paddingY = 20;

  // Price scaling
  const points = chartData?.points || [];
  const candles = chartData?.candles || [];
  const minPrice = chartData ? chartData.low * 0.998 : stock.performance.todayLow;
  const maxPrice = chartData ? chartData.high * 1.002 : stock.performance.todayHigh;
  const priceRange = maxPrice - minPrice || 1;

  const getSvgY = (price: number) => {
    return (
      svgHeight -
      paddingY -
      ((price - minPrice) / priceRange) * (svgHeight - paddingY * 2)
    );
  };

  const getSvgX = (index: number, total: number) => {
    return paddingX + (index / Math.max(1, total - 1)) * (svgWidth - paddingX * 2);
  };

  const polylinePoints = points
    .map((pt, i) => `${getSvgX(i, points.length)},${getSvgY(pt.price)}`)
    .join(' ');

  const areaPoints = points.length > 0
    ? `${paddingX},${svgHeight - paddingY} ${polylinePoints} ${getSvgX(
        points.length - 1,
        points.length
      )},${svgHeight - paddingY}`
    : '';

  // Touch / mouse scrubbing handler for chart
  const handleChartTouchMove = (clientX: number) => {
    if (!chartSvgRef.current || points.length === 0) return;
    const rect = chartSvgRef.current.getBoundingClientRect();
    const relativeX = clientX - rect.left;
    const clampedX = Math.max(0, Math.min(rect.width, relativeX));
    const ratio = clampedX / rect.width;
    const index = Math.min(
      points.length - 1,
      Math.max(0, Math.round(ratio * (points.length - 1)))
    );
    setHoveredIndex(index);
    setHoveredPoint(points[index]);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `${stock.name} - Groww Stock Update`,
        text: `${stock.name} (${stock.companyInfo.nseSymbol}) is trading at ${formatIndianCurrency(
          stock.price
        )} (${stock.changePercent >= 0 ? '+' : ''}${stock.changePercent.toFixed(2)}%)`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(
        `${stock.name} is trading at ₹${stock.price} (${stock.changePercent >= 0 ? '+' : ''}${stock.changePercent}%)`
      );
      setShowShareToast(true);
      setTimeout(() => setShowShareToast(false), 2000);
    }
  };

  // Performance calculations for Groww slider
  const dayProgress = Math.min(
    100,
    Math.max(
      0,
      ((stock.price - stock.performance.todayLow) /
        Math.max(1, stock.performance.todayHigh - stock.performance.todayLow)) *
        100
    )
  );

  const yearProgress = Math.min(
    100,
    Math.max(
      0,
      ((stock.price - stock.performance.fiftyTwoWeekLow) /
        Math.max(
          1,
          stock.performance.fiftyTwoWeekHigh - stock.performance.fiftyTwoWeekLow
        )) *
        100
    )
  );

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div
        className="relative w-full max-w-lg bg-[#121212] text-white border-t sm:border border-[#282828] rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[94vh] sm:max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Navigation Bar */}
        <div className="sticky top-0 z-30 bg-[#121212]/95 backdrop-blur-md px-4 py-3.5 border-b border-[#222222] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="p-1.5 -ml-1 rounded-full text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-1.5 bg-[#1e1e1e] p-0.5 rounded-lg border border-[#303030] text-[11px] font-semibold">
              <button
                onClick={() => setExchange('NSE')}
                className={`px-2 py-0.5 rounded-md transition-colors ${
                  exchange === 'NSE' ? 'bg-[#00D09C] text-black font-bold' : 'text-zinc-400'
                }`}
              >
                NSE
              </button>
              <button
                onClick={() => setExchange('BSE')}
                className={`px-2 py-0.5 rounded-md transition-colors ${
                  exchange === 'BSE' ? 'bg-[#00D09C] text-black font-bold' : 'text-zinc-400'
                }`}
              >
                BSE
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleShare}
              className="p-2 rounded-full text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
            >
              <Share2 className="w-4 h-4" />
            </button>
            <button
              onClick={() => onToggleWatchlist(stock.symbol)}
              className={`p-2 rounded-full border transition-colors ${
                isWatchlisted
                  ? 'bg-[#00D09C]/15 text-[#00D09C] border-[#00D09C]/30'
                  : 'text-zinc-400 border-zinc-800 hover:text-white'
              }`}
            >
              <Bookmark className={`w-4 h-4 ${isWatchlisted ? 'fill-[#00D09C]' : ''}`} />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto px-4 py-4 space-y-6 pb-24">
          {/* Stock Name & Price Header */}
          <div>
            <div className="flex items-start justify-between gap-2">
              <div>
                <h1 className="text-xl font-bold text-white tracking-tight leading-tight">
                  {stock.name}
                </h1>
                <div className="text-xs text-zinc-400 font-mono mt-0.5">
                  {stock.companyInfo.nseSymbol} • {stock.companyInfo.industry} • {stock.marketCapCategory}
                </div>
              </div>

              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-zinc-800 to-zinc-900 border border-zinc-700 flex items-center justify-center font-bold text-sm text-[#00D09C] shadow-sm">
                {stock.companyInfo.nseSymbol.slice(0, 2)}
              </div>
            </div>

            {/* Price & Change */}
            <div className="mt-3">
              <div className="text-3xl font-bold font-mono tracking-tight text-white">
                {formatIndianCurrency(currentPrice)}
              </div>
              <div
                className={`flex items-center gap-1 text-sm font-semibold font-mono mt-0.5 ${
                  isPositive ? 'text-[#00D09C]' : 'text-[#EF4444]'
                }`}
              >
                {isPositive ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                <span>
                  {isPositive ? '+' : ''}
                  {formatIndianNumber(activeChange)} ({isPositive ? '+' : ''}
                  {activeChangePct.toFixed(2)}%)
                </span>
                <span className="text-zinc-500 font-normal text-xs ml-1 font-sans">
                  {timeRange === '1D' ? '1D' : timeRange}
                </span>
              </div>
              {hoveredPoint && (
                <div className="text-[11px] text-[#00D09C] font-mono mt-0.5">
                  Point: {hoveredPoint.timeStr} ({hoveredPoint.dateStr})
                </div>
              )}
            </div>
          </div>

          {/* Chart Section */}
          <div className="bg-[#181818] rounded-2xl p-3 border border-[#262626]">
            {/* Chart Type Toggle & Time Range */}
            <div className="flex items-center justify-between pb-2 border-b border-[#262626]">
              {/* Timeframes */}
              <div className="flex items-center gap-1 text-xs">
                {(['1D', '1W', '1M', '1Y', '5Y', 'ALL'] as TimeRange[]).map((r) => (
                  <button
                    key={r}
                    onClick={() => setTimeRange(r)}
                    className={`px-2.5 py-1 rounded-lg font-semibold transition-all ${
                      timeRange === r
                        ? 'bg-[#00D09C] text-black'
                        : 'text-zinc-400 hover:text-white hover:bg-zinc-800'
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>

              {/* Line vs Candle Switcher */}
              <button
                onClick={() => setChartType(chartType === 'line' ? 'candle' : 'line')}
                className="p-1.5 rounded-lg bg-[#222222] text-zinc-400 hover:text-white border border-[#303030]"
                title="Toggle Candlestick / Line Chart"
              >
                {chartType === 'line' ? (
                  <CandleIcon className="w-4 h-4 text-[#00D09C]" />
                ) : (
                  <LineIcon className="w-4 h-4 text-[#00D09C]" />
                )}
              </button>
            </div>

            {/* Interactive SVG Chart */}
            <div
              className="relative w-full pt-3 touch-none select-none"
              onTouchMove={(e) => handleChartTouchMove(e.touches[0].clientX)}
              onMouseMove={(e) => handleChartTouchMove(e.clientX)}
              onMouseLeave={() => {
                setHoveredPoint(null);
                setHoveredIndex(null);
              }}
            >
              <svg
                ref={chartSvgRef}
                viewBox={`0 0 ${svgWidth} ${svgHeight}`}
                className="w-full h-48 overflow-visible cursor-crosshair"
              >
                <defs>
                  <linearGradient id="growwChartGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop
                      offset="0%"
                      stopColor={isPositive ? '#00D09C' : '#EF4444'}
                      stopOpacity="0.28"
                    />
                    <stop
                      offset="100%"
                      stopColor={isPositive ? '#00D09C' : '#EF4444'}
                      stopOpacity="0.0"
                    />
                  </linearGradient>
                </defs>

                {/* Subtle Horizontal grid lines */}
                <line
                  x1={paddingX}
                  y1={paddingY}
                  x2={svgWidth - paddingX}
                  y2={paddingY}
                  stroke="#262626"
                  strokeDasharray="2 2"
                />
                <line
                  x1={paddingX}
                  y1={svgHeight / 2}
                  x2={svgWidth - paddingX}
                  y2={svgHeight / 2}
                  stroke="#262626"
                  strokeDasharray="2 2"
                />
                <line
                  x1={paddingX}
                  y1={svgHeight - paddingY}
                  x2={svgWidth - paddingX}
                  y2={svgHeight - paddingY}
                  stroke="#262626"
                  strokeDasharray="2 2"
                />

                {chartType === 'line' ? (
                  <>
                    {/* Area polygon */}
                    <polygon points={areaPoints} fill="url(#growwChartGrad)" />

                    {/* Main Line */}
                    <polyline
                      fill="none"
                      stroke={isPositive ? '#00D09C' : '#EF4444'}
                      strokeWidth="2.2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      points={polylinePoints}
                    />
                  </>
                ) : (
                  /* Candlesticks view */
                  candles.map((candle, idx) => {
                    const x = getSvgX(idx, candles.length);
                    const openY = getSvgY(candle.open);
                    const closeY = getSvgY(candle.close);
                    const highY = getSvgY(candle.high);
                    const lowY = getSvgY(candle.low);
                    const isGreen = candle.close >= candle.open;
                    const candleColor = isGreen ? '#00D09C' : '#EF4444';
                    const bodyTop = Math.min(openY, closeY);
                    const bodyHeight = Math.max(2, Math.abs(openY - closeY));
                    const candleWidth = Math.max(2, (svgWidth / candles.length) * 0.6);

                    return (
                      <g key={idx}>
                        {/* Wick */}
                        <line
                          x1={x}
                          y1={highY}
                          x2={x}
                          y2={lowY}
                          stroke={candleColor}
                          strokeWidth="1.2"
                        />
                        {/* Body */}
                        <rect
                          x={x - candleWidth / 2}
                          y={bodyTop}
                          width={candleWidth}
                          height={bodyHeight}
                          fill={candleColor}
                          rx="0.5"
                        />
                      </g>
                    );
                  })
                )}

                {/* Scrubber Cursor indicator */}
                {hoveredIndex !== null && points[hoveredIndex] && (
                  <>
                    <line
                      x1={getSvgX(hoveredIndex, points.length)}
                      y1={paddingY}
                      x2={getSvgX(hoveredIndex, points.length)}
                      y2={svgHeight - paddingY}
                      stroke="#888888"
                      strokeWidth="1"
                      strokeDasharray="3 3"
                    />
                    <circle
                      cx={getSvgX(hoveredIndex, points.length)}
                      cy={getSvgY(points[hoveredIndex].price)}
                      r="4.5"
                      fill={isPositive ? '#00D09C' : '#EF4444'}
                      stroke="#121212"
                      strokeWidth="2"
                    />
                  </>
                )}
              </svg>

              {/* Chart Date Range footer */}
              {points.length > 1 && (
                <div className="flex justify-between text-[10px] text-zinc-500 font-mono px-1">
                  <span>{points[0].timeStr}</span>
                  <span>{points[Math.floor(points.length / 2)].timeStr}</span>
                  <span>{points[points.length - 1].timeStr}</span>
                </div>
              )}
            </div>
          </div>

          {/* Groww Performance Meters Section */}
          <div className="space-y-4">
            <h2 className="text-base font-bold text-white flex items-center justify-between">
              <span>Performance</span>
              <span className="text-xs font-normal text-zinc-400">Today & 52-Week</span>
            </h2>

            {/* Today's Low / High Meter */}
            <div className="bg-[#181818] p-3.5 rounded-2xl border border-[#262626] space-y-2">
              <div className="flex justify-between text-xs font-mono">
                <div>
                  <span className="text-zinc-400 text-[10px] block">Today's Low</span>
                  <span className="font-semibold text-white">
                    {formatIndianCurrency(stock.performance.todayLow)}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-zinc-400 text-[10px] block">Today's High</span>
                  <span className="font-semibold text-white">
                    {formatIndianCurrency(stock.performance.todayHigh)}
                  </span>
                </div>
              </div>

              {/* Meter bar */}
              <div className="relative w-full h-2 bg-zinc-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-red-500 via-amber-400 to-[#00D09C] rounded-full"
                  style={{ width: '100%' }}
                />
              </div>

              <div className="flex justify-center">
                <span className="text-[10px] text-zinc-400 font-mono bg-[#222222] px-2 py-0.5 rounded-full border border-[#303030]">
                  LTP: {formatIndianCurrency(stock.price)} ({dayProgress.toFixed(0)}% of range)
                </span>
              </div>
            </div>

            {/* 52-Week Low / High Meter */}
            <div className="bg-[#181818] p-3.5 rounded-2xl border border-[#262626] space-y-2">
              <div className="flex justify-between text-xs font-mono">
                <div>
                  <span className="text-zinc-400 text-[10px] block">52W Low</span>
                  <span className="font-semibold text-white">
                    {formatIndianCurrency(stock.performance.fiftyTwoWeekLow)}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-zinc-400 text-[10px] block">52W High</span>
                  <span className="font-semibold text-white">
                    {formatIndianCurrency(stock.performance.fiftyTwoWeekHigh)}
                  </span>
                </div>
              </div>

              {/* Meter bar */}
              <div className="relative w-full h-2 bg-zinc-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-red-500 via-yellow-400 to-[#00D09C] rounded-full"
                  style={{ width: '100%' }}
                />
              </div>

              <div className="flex justify-center">
                <span className="text-[10px] text-zinc-400 font-mono bg-[#222222] px-2 py-0.5 rounded-full border border-[#303030]">
                  {yearProgress.toFixed(0)}% of 52-Week Range
                </span>
              </div>
            </div>

            {/* Performance Stats Grid */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="bg-[#181818] p-3 rounded-xl border border-[#242424] flex justify-between">
                <span className="text-zinc-400">Open</span>
                <span className="font-mono font-semibold text-white">
                  {formatIndianCurrency(stock.performance.openPrice)}
                </span>
              </div>

              <div className="bg-[#181818] p-3 rounded-xl border border-[#242424] flex justify-between">
                <span className="text-zinc-400">Prev. Close</span>
                <span className="font-mono font-semibold text-white">
                  {formatIndianCurrency(stock.performance.prevClose)}
                </span>
              </div>

              <div className="bg-[#181818] p-3 rounded-xl border border-[#242424] flex justify-between">
                <span className="text-zinc-400">Volume</span>
                <span className="font-mono font-semibold text-white">
                  {formatIndianCompact(stock.performance.volume)}
                </span>
              </div>

              <div className="bg-[#181818] p-3 rounded-xl border border-[#242424] flex justify-between">
                <span className="text-zinc-400">Total Traded Value</span>
                <span className="font-mono font-semibold text-white">
                  ₹{stock.performance.totalTradedValueCr} Cr
                </span>
              </div>

              <div className="bg-[#181818] p-3 rounded-xl border border-[#242424] flex justify-between">
                <span className="text-zinc-400">Upper Circuit (+10%)</span>
                <span className="font-mono font-semibold text-[#00D09C]">
                  {formatIndianCurrency(stock.performance.upperCircuit)}
                </span>
              </div>

              <div className="bg-[#181818] p-3 rounded-xl border border-[#242424] flex justify-between">
                <span className="text-zinc-400">Lower Circuit (-10%)</span>
                <span className="font-mono font-semibold text-[#EF4444]">
                  {formatIndianCurrency(stock.performance.lowerCircuit)}
                </span>
              </div>
            </div>
          </div>

          {/* Fundamentals Section (Groww Style) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-white">Fundamentals</h2>
              <span className="text-xs text-zinc-400 font-mono">Consolidated</span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="bg-[#181818] p-3 rounded-xl border border-[#242424] flex justify-between">
                <span className="text-zinc-400">Market Cap</span>
                <span className="font-mono font-semibold text-white">
                  ₹{formatIndianNumber(stock.fundamentals.marketCapCr)} Cr
                </span>
              </div>

              <div className="bg-[#181818] p-3 rounded-xl border border-[#242424] flex justify-between">
                <span className="text-zinc-400">P/E Ratio</span>
                <span className="font-mono font-semibold text-white">
                  {stock.fundamentals.peRatio.toFixed(2)}
                </span>
              </div>

              <div className="bg-[#181818] p-3 rounded-xl border border-[#242424] flex justify-between">
                <span className="text-zinc-400">P/B Ratio</span>
                <span className="font-mono font-semibold text-white">
                  {stock.fundamentals.pbRatio.toFixed(2)}
                </span>
              </div>

              <div className="bg-[#181818] p-3 rounded-xl border border-[#242424] flex justify-between">
                <span className="text-zinc-400">Industry P/E</span>
                <span className="font-mono font-semibold text-white">
                  {stock.fundamentals.industryPe.toFixed(2)}
                </span>
              </div>

              <div className="bg-[#181818] p-3 rounded-xl border border-[#242424] flex justify-between">
                <span className="text-zinc-400">Debt to Equity</span>
                <span className="font-mono font-semibold text-white">
                  {stock.fundamentals.debtToEquity.toFixed(2)}
                </span>
              </div>

              <div className="bg-[#181818] p-3 rounded-xl border border-[#242424] flex justify-between">
                <span className="text-zinc-400">ROE %</span>
                <span className="font-mono font-semibold text-[#00D09C]">
                  {stock.fundamentals.roePercent.toFixed(2)}%
                </span>
              </div>

              <div className="bg-[#181818] p-3 rounded-xl border border-[#242424] flex justify-between">
                <span className="text-zinc-400">EPS (TTM)</span>
                <span className="font-mono font-semibold text-white">
                  ₹{stock.fundamentals.epsTtm.toFixed(2)}
                </span>
              </div>

              <div className="bg-[#181818] p-3 rounded-xl border border-[#242424] flex justify-between">
                <span className="text-zinc-400">Div. Yield</span>
                <span className="font-mono font-semibold text-white">
                  {stock.fundamentals.divYieldPercent.toFixed(2)}%
                </span>
              </div>
            </div>
          </div>

          {/* About Company */}
          <div className="space-y-3">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Building2 className="w-4 h-4 text-[#00D09C]" />
              About {stock.name}
            </h2>

            <p className="text-xs text-zinc-300 leading-relaxed bg-[#181818] p-3.5 rounded-2xl border border-[#242424]">
              {stock.companyInfo.about}
            </p>

            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between py-1 border-b border-zinc-800 text-zinc-400">
                <span>MD / CEO</span>
                <span className="text-white font-medium">{stock.companyInfo.managingDirector}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-zinc-800 text-zinc-400">
                <span>Parent Organization</span>
                <span className="text-white font-medium">{stock.companyInfo.parentOrg}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-zinc-800 text-zinc-400">
                <span>Headquarters</span>
                <span className="text-white font-medium">{stock.companyInfo.headquarters}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-zinc-800 text-zinc-400">
                <span>Founded</span>
                <span className="text-white font-medium">{stock.companyInfo.foundedYear}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-zinc-800 text-zinc-400">
                <span>NSE Symbol</span>
                <span className="text-white font-mono">{stock.companyInfo.nseSymbol}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-zinc-800 text-zinc-400">
                <span>BSE Scrip Code</span>
                <span className="text-white font-mono">{stock.companyInfo.bseCode}</span>
              </div>
              <div className="flex justify-between py-1 text-zinc-400">
                <span>ISIN</span>
                <span className="text-white font-mono">{stock.companyInfo.isin}</span>
              </div>
            </div>
          </div>

          {/* Exchange Disclaimer */}
          <div className="p-3 bg-[#161616] rounded-xl border border-zinc-800/80 text-[11px] text-zinc-400 flex items-center gap-2">
            <Clock className="w-3.5 h-3.5 text-zinc-500 shrink-0" />
            <span>
              Realtime/delayed price feed from National Stock Exchange of India (NSE). Market info only.
            </span>
          </div>
        </div>

        {/* Floating Bottom Action Bar */}
        <div className="sticky bottom-0 z-30 bg-[#121212] border-t border-[#262626] p-3 px-4 flex items-center gap-3">
          <button
            onClick={() => onToggleWatchlist(stock.symbol)}
            className={`flex-1 py-3 px-4 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all ${
              isWatchlisted
                ? 'bg-zinc-800 text-[#00D09C] border border-[#00D09C]/40'
                : 'bg-[#00D09C] text-black hover:bg-[#00b386] shadow-lg shadow-[#00D09C]/20'
            }`}
          >
            <Bookmark className={`w-4 h-4 ${isWatchlisted ? 'fill-[#00D09C]' : ''}`} />
            <span>{isWatchlisted ? 'In Watchlist (Tap to Remove)' : 'Add to Watchlist'}</span>
          </button>
        </div>

        {/* Toast */}
        {showShareToast && (
          <div className="absolute top-14 left-1/2 -translate-x-1/2 bg-[#00D09C] text-black text-xs font-bold px-3 py-1.5 rounded-full shadow-lg animate-bounce">
            Copied link to clipboard!
          </div>
        )}
      </div>
    </div>
  );
};

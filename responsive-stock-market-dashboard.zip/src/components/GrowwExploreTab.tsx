import React, { useState } from 'react';
import {
  IndianStockQuote,
  SectorData,
  CapCategory,
  MarketBreadth,
} from '../types/market';
import { formatIndianCurrency } from '../services/marketDataService';
import {
  TrendingUp,
  TrendingDown,
  Activity,
  Layers,
  Flame,
  Bookmark,
  Sparkles,
} from 'lucide-react';

interface GrowwExploreTabProps {
  gainers: IndianStockQuote[];
  losers: IndianStockQuote[];
  mostActive: IndianStockQuote[];
  fiftyTwoWeekHigh: IndianStockQuote[];
  sectors: SectorData[];
  breadth: MarketBreadth;
  watchlistSymbols: string[];
  onSelectStock: (symbol: string) => void;
  onToggleWatchlist: (symbol: string) => void;
}

export const GrowwExploreTab: React.FC<GrowwExploreTabProps> = ({
  gainers,
  losers,
  mostActive,
  fiftyTwoWeekHigh,
  sectors,
  breadth,
  watchlistSymbols,
  onSelectStock,
  onToggleWatchlist,
}) => {
  const [moverType, setMoverType] = useState<'gainers' | 'losers' | 'active' | '52w'>('gainers');
  const [capCategory, setCapCategory] = useState<CapCategory>('All');

  // Filter list
  let rawList =
    moverType === 'gainers'
      ? gainers
      : moverType === 'losers'
      ? losers
      : moverType === 'active'
      ? mostActive
      : fiftyTwoWeekHigh;

  const currentList =
    capCategory === 'All'
      ? rawList
      : rawList.filter((s) => s.marketCapCategory === capCategory);

  return (
    <div className="space-y-6 pb-6">
      {/* Groww Quick Action Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none -mx-4 px-4 sm:mx-0 sm:px-0">
        <button
          onClick={() => setMoverType('gainers')}
          className={`shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all ${
            moverType === 'gainers'
              ? 'bg-[#00D09C] text-black shadow-md shadow-[#00D09C]/20'
              : 'bg-[#1a1a1a] text-zinc-300 border border-[#2a2a2a]'
          }`}
        >
          <TrendingUp className="w-3.5 h-3.5" /> Top Gainers
        </button>

        <button
          onClick={() => setMoverType('losers')}
          className={`shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all ${
            moverType === 'losers'
              ? 'bg-[#EF4444] text-white shadow-md shadow-[#EF4444]/20'
              : 'bg-[#1a1a1a] text-zinc-300 border border-[#2a2a2a]'
          }`}
        >
          <TrendingDown className="w-3.5 h-3.5" /> Top Losers
        </button>

        <button
          onClick={() => setMoverType('active')}
          className={`shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all ${
            moverType === 'active'
              ? 'bg-blue-500 text-white shadow-md shadow-blue-500/20'
              : 'bg-[#1a1a1a] text-zinc-300 border border-[#2a2a2a]'
          }`}
        >
          <Activity className="w-3.5 h-3.5" /> Most Active
        </button>

        <button
          onClick={() => setMoverType('52w')}
          className={`shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all ${
            moverType === '52w'
              ? 'bg-amber-500 text-black shadow-md shadow-amber-500/20'
              : 'bg-[#1a1a1a] text-zinc-300 border border-[#2a2a2a]'
          }`}
        >
          <Flame className="w-3.5 h-3.5" /> 52W High
        </button>
      </div>

      {/* Market Movers Card List (Groww Style) */}
      <div className="bg-[#181818] rounded-2xl border border-[#262626] p-4 shadow-sm space-y-3">
        {/* Subheader with Cap Category selector */}
        <div className="flex items-center justify-between pb-2 border-b border-[#262626]">
          <span className="text-xs font-bold uppercase tracking-wider text-zinc-400">
            {moverType === 'gainers'
              ? 'Top Gainers in NSE'
              : moverType === 'losers'
              ? 'Top Losers in NSE'
              : moverType === 'active'
              ? 'Most Active by Value'
              : 'Stocks near 52W High'}
          </span>

          <div className="flex items-center gap-1 text-[10px]">
            {(['All', 'Large Cap'] as CapCategory[]).map((cat) => (
              <button
                key={cat}
                onClick={() => setCapCategory(cat)}
                className={`px-2 py-0.5 rounded-md font-medium ${
                  capCategory === cat ? 'bg-[#282828] text-[#00D09C]' : 'text-zinc-500'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Stock Items */}
        <div className="divide-y divide-[#242424]">
          {currentList.map((stock) => {
            const isPositive = stock.changePercent >= 0;
            const isWatch = watchlistSymbols.includes(stock.symbol);

            return (
              <div
                key={stock.symbol}
                onClick={() => onSelectStock(stock.symbol)}
                className="group py-3 flex items-center justify-between hover:bg-[#202020] -mx-2 px-2 rounded-xl cursor-pointer transition-colors"
              >
                {/* Left: Monogram & Details */}
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-zinc-800 to-zinc-900 border border-zinc-700/80 flex items-center justify-center text-xs font-bold text-[#00D09C]">
                    {stock.companyInfo.nseSymbol.slice(0, 2)}
                  </div>

                  <div>
                    <div className="text-sm font-bold text-white group-hover:text-[#00D09C] transition-colors leading-snug">
                      {stock.name}
                    </div>
                    <div className="text-[11px] text-zinc-500 font-mono">
                      {stock.companyInfo.nseSymbol} • {stock.companyInfo.industry}
                    </div>
                  </div>
                </div>

                {/* Right: Price, % Change & Watchlist */}
                <div className="flex items-center gap-3 text-right">
                  <div>
                    <div className="text-sm font-bold font-mono text-white">
                      {formatIndianCurrency(stock.price)}
                    </div>
                    <div
                      className={`text-[11px] font-mono font-semibold flex items-center justify-end gap-0.5 ${
                        isPositive ? 'text-[#00D09C]' : 'text-[#EF4444]'
                      }`}
                    >
                      {isPositive ? (
                        <TrendingUp className="w-3 h-3" />
                      ) : (
                        <TrendingDown className="w-3 h-3" />
                      )}
                      <span>
                        {isPositive ? '+' : ''}
                        {stock.changePercent.toFixed(2)}%
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleWatchlist(stock.symbol);
                    }}
                    title={isWatch ? 'Remove from Watchlist' : 'Add to Watchlist'}
                    className={`p-1.5 rounded-lg border transition-colors ${
                      isWatch
                        ? 'bg-[#00D09C]/15 text-[#00D09C] border-[#00D09C]/30'
                        : 'text-zinc-500 border-zinc-800 hover:text-white'
                    }`}
                  >
                    <Bookmark className={`w-3.5 h-3.5 ${isWatch ? 'fill-[#00D09C]' : ''}`} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Groww Market Breadth Gauge */}
      <div className="bg-[#181818] rounded-2xl border border-[#262626] p-4 shadow-sm space-y-2.5">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#00D09C]" /> NSE Market Breadth
          </span>
          <span className="text-[11px] text-zinc-400 font-mono">
            A/D Ratio: <strong className="text-[#00D09C]">{breadth.ratio}</strong>
          </span>
        </div>

        {/* Progress meter */}
        <div className="w-full h-2.5 bg-zinc-800 rounded-full overflow-hidden flex">
          <div
            className="bg-[#00D09C] h-full"
            style={{
              width: `${(breadth.advances / breadth.totalTraded) * 100}%`,
            }}
          />
          <div
            className="bg-[#EF4444] h-full"
            style={{
              width: `${(breadth.declines / breadth.totalTraded) * 100}%`,
            }}
          />
        </div>

        <div className="flex justify-between text-xs font-mono">
          <span className="text-[#00D09C] font-semibold flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-[#00D09C]" /> {breadth.advances} Advances
          </span>
          <span className="text-[#EF4444] font-semibold flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-[#EF4444]" /> {breadth.declines} Declines
          </span>
        </div>
      </div>

      {/* Sectors in Focus (Groww Heatmap Cards) */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <span className="text-xs font-bold uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-blue-400" /> Sectors in Focus
          </span>
          <span className="text-[11px] text-zinc-500">NSE Sector Indices</span>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          {sectors.map((sector) => {
            const isPos = sector.changePercent >= 0;
            return (
              <div
                key={sector.id}
                className="bg-[#181818] p-3 rounded-2xl border border-[#262626] hover:border-[#333333] transition-colors"
              >
                <div className="flex items-start justify-between gap-1 mb-1">
                  <span className="text-xs font-bold text-white truncate">
                    {sector.name}
                  </span>
                  <span
                    className={`text-[11px] font-mono font-bold ${
                      isPos ? 'text-[#00D09C]' : 'text-[#EF4444]'
                    }`}
                  >
                    {isPos ? '+' : ''}
                    {sector.changePercent.toFixed(2)}%
                  </span>
                </div>

                <div className="w-full h-1 bg-zinc-800 rounded-full overflow-hidden my-1.5">
                  <div
                    className={`h-full ${isPos ? 'bg-[#00D09C]' : 'bg-[#EF4444]'}`}
                    style={{
                      width: `${Math.min(100, Math.max(15, Math.abs(sector.changePercent) * 35))}%`,
                    }}
                  />
                </div>

                <div className="text-[10px] text-zinc-400 truncate">
                  Top: <span className="text-zinc-200">{sector.topStockName}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
